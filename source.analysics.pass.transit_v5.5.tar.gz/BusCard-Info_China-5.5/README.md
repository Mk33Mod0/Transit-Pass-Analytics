# 写在前面
大陆公交票卡分析工具

来自CSDN大佬songzp321（孤独虾）的票卡分析专用工具 

https://blog.csdn.net/songzp321/article/details/84896549

# 获取
获取下载，可前往发行页下载 

https://github.com/Cowan97/BusCard-Info_China/releases


# 最后
目前已被PP助手下架，仅做备份分享使用。如有冒犯issues请求删除。
